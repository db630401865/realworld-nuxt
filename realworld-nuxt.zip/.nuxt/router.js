import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b798beec = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _1d33723f = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _ed19c3ee = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _5b6adf6e = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _74aed824 = () => interopDefault(import('../pages/sttings' /* webpackChunkName: "" */))
const _cf367266 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _8dd658d4 = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _b798beec,
    children: [{
      path: "",
      component: _1d33723f,
      name: "home"
    }, {
      path: "/login",
      component: _ed19c3ee,
      name: "login"
    }, {
      path: "/register",
      component: _ed19c3ee,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _5b6adf6e,
      name: "profile"
    }, {
      path: "/sttings",
      component: _74aed824,
      name: "sttings"
    }, {
      path: "/editor",
      component: _cf367266,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _8dd658d4,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
